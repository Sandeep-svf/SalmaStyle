package com.barcode.salmaStyle.RetroifitApi;

public class UrlClass {

   // public static final String BaseUrl = "http://ec2-3-91-178-48.compute-1.amazonaws.com:8000/en/";
    public static final String BaseUrl = "http://69.49.235.253:8000/en/";
    //  public static final String BaseUrl = "http://192.168.1.130:8000/en/";

}
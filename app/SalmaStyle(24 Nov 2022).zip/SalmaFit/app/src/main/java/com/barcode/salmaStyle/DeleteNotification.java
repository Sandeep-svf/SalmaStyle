package com.barcode.salmaStyle;

import com.barcode.salmaStyle.response.NotificationResponse;

public interface DeleteNotification {
    void onItemClick(NotificationResponse notificationResponse, String id);
}

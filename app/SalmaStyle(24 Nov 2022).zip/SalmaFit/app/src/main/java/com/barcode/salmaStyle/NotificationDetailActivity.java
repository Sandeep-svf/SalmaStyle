package com.barcode.salmaStyle;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.barcode.salmaStyle.R;

public class NotificationDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_detail);
    }
}
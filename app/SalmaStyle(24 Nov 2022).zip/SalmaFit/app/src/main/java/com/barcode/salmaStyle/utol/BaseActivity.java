package com.barcode.salmaStyle.utol;


import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;

public abstract class BaseActivity extends AppCompatActivity {

    public static Originator contextOriginator;
    private SharedPreferences sharedPreferencesLanguageName;
    private String lang_txt;
    private String str_lanuage;


   /* private static final String TAG = "BaseActivity";

    protected void attachBaseContext(Context base){
        super.attachBaseContext(App.localeManager.setLocale(base));
        Log.d(TAG, "attachBaseContext");
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate");
        Utility.resetActivityTitle(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }*/

}
package com.barcode.salmaStyle.model;

public class ProductModel {

    String file_url;
    boolean ischecked;

    public boolean isIschecked() {
        return ischecked;
    }

    public String getFile_url() {
        return file_url;
    }

    public void setFile_url(String file_url) {
        this.file_url = file_url;
    }

    public void setIschecked(boolean ischecked) {
        this.ischecked = ischecked;
    }


}

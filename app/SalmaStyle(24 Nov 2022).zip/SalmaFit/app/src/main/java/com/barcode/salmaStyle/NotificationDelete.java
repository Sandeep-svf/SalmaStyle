package com.barcode.salmaStyle;

public interface NotificationDelete {
    void onItemClick(int position, String id);
}

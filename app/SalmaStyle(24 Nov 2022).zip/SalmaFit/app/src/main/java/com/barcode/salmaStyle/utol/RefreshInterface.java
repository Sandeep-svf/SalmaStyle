package com.barcode.salmaStyle.utol;

public interface RefreshInterface {

    void Refresh();
}
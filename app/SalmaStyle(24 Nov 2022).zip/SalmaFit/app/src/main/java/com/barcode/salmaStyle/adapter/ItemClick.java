package com.barcode.salmaStyle.adapter;

public interface ItemClick {
    void sendclickEvent(int position);
}
